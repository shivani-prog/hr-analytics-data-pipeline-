CREATE TABLE [dbo].[fact_payroll] (

	[id] int NULL, 
	[employee_id] int NULL, 
	[payroll_month] date NULL, 
	[gross] int NULL, 
	[net] int NULL, 
	[tds] int NULL
);