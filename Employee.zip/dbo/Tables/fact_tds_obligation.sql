CREATE TABLE [dbo].[fact_tds_obligation] (

	[employee_id] int NULL, 
	[payroll_month] date NULL, 
	[total_tds] int NULL
);