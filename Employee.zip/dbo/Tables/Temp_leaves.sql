CREATE TABLE [dbo].[Temp_leaves] (

	[id] int NULL, 
	[employee_id] int NULL, 
	[date] date NULL, 
	[type] varchar(100) NULL, 
	[Loaded_at] datetime2(3) NULL
);