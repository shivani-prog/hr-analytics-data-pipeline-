CREATE TABLE [dbo].[Temp_payroll] (

	[id] int NULL, 
	[employee_id] int NULL, 
	[month] date NULL, 
	[gross] int NULL, 
	[net] int NULL, 
	[tds] int NULL, 
	[Loaded_at] datetime2(3) NULL
);