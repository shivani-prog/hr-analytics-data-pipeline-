CREATE TABLE [dbo].[fact_leaves] (

	[id] int NULL, 
	[employee_id] int NULL, 
	[leave_date] date NULL
);