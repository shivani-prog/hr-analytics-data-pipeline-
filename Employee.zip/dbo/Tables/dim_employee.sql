CREATE TABLE [dbo].[dim_employee] (

	[id] int NULL, 
	[first_name] varchar(100) NULL, 
	[last_name] varchar(100) NULL, 
	[full_name] varchar(100) NULL, 
	[join_date] date NULL, 
	[dept] varchar(100) NULL
);