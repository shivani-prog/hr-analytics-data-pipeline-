CREATE TABLE [dbo].[fact_payroll_monthly] (

	[employee_id] int NULL, 
	[payroll_month] date NULL, 
	[total_gross] int NULL, 
	[total_net] int NULL, 
	[total_tds] int NULL
);