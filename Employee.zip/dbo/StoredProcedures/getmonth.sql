CREATE PROCEDURE getmonth (@month INT)
AS
BEGIN
    SELECT 
        a.payroll_month,
        SUM(a.total_gross) AS gross_payroll,
        SUM(a.total_net) AS net_payroll,
        SUM(b.total_tds) AS tds_due,
        COUNT(DISTINCT a.employee_id) AS active_employees
    FROM fact_payroll_monthly a
    LEFT JOIN fact_tds_obligation b  
        ON a.employee_id = b.employee_id 
        AND a.payroll_month = b.payroll_month
    WHERE MONTH(a.payroll_month) = @month
    GROUP BY a.payroll_month;
END;